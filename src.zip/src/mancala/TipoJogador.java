/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mancala;

/**
 *
 * @author DanielSilva
 */
public enum TipoJogador {

    /**
     *
     */
    JOGADOR_1,

    /**
     *
     */
    JOGADOR_2,

    /**
     *
     */
    COMPUTADOR;
	
   
}
