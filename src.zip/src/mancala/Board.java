/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mancala;

/**
 * Aqui está representado o campo de jogo 
 * @author DanielSilva
 */
public class Board {
    boolean ganhou;
    int jogadores[];
    int pontosJogadorA;
    int pontosJogadorB;
    
}
